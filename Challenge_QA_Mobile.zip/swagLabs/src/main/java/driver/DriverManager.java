package driver;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DriverManager {
    private static   AppiumDriver<MobileElement> appiumDriver;
    public static void createAppiumDriver() throws MalformedURLException {


        Logger.getGlobal().log(Level.INFO,"Iniciando el driver......");
        DesiredCapabilities desiredCapabilities =new DesiredCapabilities();
        desiredCapabilities.setCapability(MobileCapabilityType.PLATFORM_NAME,"Android");
        desiredCapabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION,"9");
        desiredCapabilities.setCapability(MobileCapabilityType.DEVICE_NAME,"HUAWEI Y6 2019");
        desiredCapabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME ,"UiAutomator2");
        desiredCapabilities.setCapability(MobileCapabilityType.APP,"C:/apk/Android.SauceLabs.Mobile.Sample.app.2.7.1.apk");
        desiredCapabilities.setCapability("appActivity","com.swaglabsmobileapp.MainActivity");
        desiredCapabilities.setCapability("appPackage","com.swaglabsmobileapp");
        desiredCapabilities.setCapability(MobileCapabilityType.UDID,"5DN6R19422005914");
        desiredCapabilities.setCapability("noReset",true);

        Logger.getGlobal().log(Level.INFO,"capabilities -->{0}",desiredCapabilities);

        appiumDriver = new AndroidDriver<MobileElement>(new URL("http://127.0.0.1:4723/wd/hub"), desiredCapabilities);

        appiumDriver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        Logger.getGlobal().log(Level.INFO,"Iniciando......");
    }

    public  static  AppiumDriver  getAppiumDriver(){
            return appiumDriver;
    }
    public  static  void  stopAppiumDriver(){
        appiumDriver.quit();
    }
}
