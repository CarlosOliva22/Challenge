package com.bdd.view;

import driver.BaseView;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;

public class SwagLabsView  extends BaseView {

    @AndroidFindBy(xpath = "//android.widget.EditText[@content-desc=\"test-Usuario\"]")
    private MobileElement txtUsuario;

    @AndroidFindBy(xpath = "//android.widget.EditText[@content-desc=\"test-Contraseña\"]")
    private MobileElement txtPassword;

    @AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"test-LOGIN\"]")
    private MobileElement btnLogins;


    @AndroidFindBy(xpath = "//android.widget.TextView[@text=\"PRODUCTOS\"]")
    private MobileElement lblTitulo;

    @AndroidFindBy(xpath = "(//android.view.ViewGroup[@content-desc=\"test-Articulo\"])[1]/android.view.ViewGroup/android.widget.ImageView")
    private MobileElement listItem;

    public void ingresarUsuario(String usuario) {
        txtUsuario.sendKeys(usuario);
    }

    public void ingresarPassword(String pass) {
        txtPassword.sendKeys(pass);
    }

    public void clickearLogins() {
        btnLogins.click();
    }

    public boolean validarTitulo(String productos) {
        return lblTitulo.getText().equalsIgnoreCase(productos);
    }

    public boolean validarItems() {
        return  listItem.isDisplayed();
    }


}
