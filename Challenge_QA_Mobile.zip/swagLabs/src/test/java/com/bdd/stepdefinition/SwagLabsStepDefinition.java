package com.bdd.stepdefinition;

import com.bdd.step.SwagLabsStep;
import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import java.net.MalformedURLException;

public class SwagLabsStepDefinition {

    private SwagLabsStep swagLabsStep;
    @Before
    public void beforeScenario(){
        swagLabsStep = new SwagLabsStep();
    }

    @Given("cargar aplicativo SWAGLABS")
    public void cargarAplicativoSWAGLABS() throws MalformedURLException {
        swagLabsStep.cargar_Aplicativo();
    }

    @When("ingresar usuario {string}")
    public void ingresar_Usuario(String usuario) {
        swagLabsStep.ingresarUsuario(usuario);
    }

    @And("ingresar password {string}")
    public void ingresar_Password(String pass) {
        swagLabsStep.ingresarPassword(pass);
    }

    @And("clickear Logins")
    public void clickear_Logins() {
        swagLabsStep.clickearLogins();
    }

    @And("validar titulo {string}")
    public void validarTitulo(String productos) {
        swagLabsStep.validarTitulo(productos);
    }

    @And("validar que exista al menos un item")
    public void validarQueExistaAlMenosUnItem() {
        swagLabsStep.validarItems();
    }

}
