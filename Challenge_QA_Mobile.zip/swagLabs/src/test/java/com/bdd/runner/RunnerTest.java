package com.bdd.runner;


import driver.DriverManager;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.AfterClass;
import org.junit.runner.RunWith;

import java.util.logging.Level;
import java.util.logging.Logger;

@RunWith(Cucumber.class)
@CucumberOptions(
        features = "src/test/resources/features",
        glue ="com.bdd.stepdefinition",
        stepNotifications = true,
        tags = "@MOBILE1")
public class RunnerTest {

    @AfterClass
    public static void affterExecution(){
        Logger.getGlobal().log(Level.INFO,"Deteniendo el Driver......");
        DriverManager.stopAppiumDriver();
    }
}
