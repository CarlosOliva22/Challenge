package com.bdd.step;

import com.bdd.view.SwagLabsView;
import driver.DriverManager;
import org.junit.Assert;

import java.net.MalformedURLException;

public class SwagLabsStep {

    private SwagLabsView swagLabsView(){
      return new SwagLabsView();
    }
    public void cargar_Aplicativo() throws MalformedURLException {
        DriverManager.createAppiumDriver();
    }

    public void ingresarUsuario(String usuario) {
        swagLabsView().ingresarUsuario(usuario);
    }
    public void ingresarPassword(String pass) {
        swagLabsView().ingresarPassword(pass);
    }

    public void clickearLogins() {
        swagLabsView().clickearLogins();
    }

    public void validarTitulo(String productos) {
        Assert.assertTrue(swagLabsView().validarTitulo(productos));

    }

    public void validarItems() {
        Assert.assertTrue(swagLabsView().validarItems());
    }


}
