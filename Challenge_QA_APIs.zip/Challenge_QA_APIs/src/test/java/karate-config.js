function fn() {
    var env = karate.env;
    var urlBase = ''
    var urlBooking = ''
    var urlPet = ''

    karate.log('Se realizó la ejecución en el ambiente: ', env);
    karate.configure('ssl', true);

 if (!env) {
     env = 'dev';
     var urlPet = 'https://petstore.swagger.io/v2'
 }
 if (env === 'dev') {
    var urlPet = 'https://petstore.swagger.io/v2'

 } else if (env === 'cert') {
    var urlBase = 'https://reqres.in/'
    var urlBooking = 'https://restful-booker.herokuapp.com'
    var urlPet = 'https://petstore.swagger.io/v2'

 }

 var config = {
     env: env,
     urlBase: urlBase,
     urlBooking: urlBooking,
     urlPet: urlPet

 }

 return config;
 }