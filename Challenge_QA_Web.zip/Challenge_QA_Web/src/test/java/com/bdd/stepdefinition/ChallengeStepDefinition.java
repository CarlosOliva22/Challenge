package com.bdd.stepdefinition;

import com.bdd.step.ChallengeStep;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;

public class ChallengeStepDefinition {

    @Steps
    private ChallengeStep challengeStep;

    @Given("^Cargar la pagina de saucedemo$")
    public void Cargar_la_pagina_de_saucedemo() {
        challengeStep.cargarPaginaSaucedemo();
    }


    @When("^Escribir mi username \"([^\"]*)\"$")
    public void escribirMiUsername(String sUsername) throws Throwable {
        challengeStep.escribirUsernameSaucedemo(sUsername);
    }

    @And("^Escribir mi password \"([^\"]*)\"$")
    public void escribirMiPassword(String sPassword) throws Throwable {
        challengeStep.escribirPasswordSaucedemo(sPassword);
    }

    @And("^ingresar a saucedemo$")
    public void ingresar_saucedemo() throws InterruptedException {
        challengeStep.clickEnLogin();
    }

    @And("^seleccionar productos$")
    public void seleccionar_productos() throws InterruptedException {
        challengeStep.clickEnProductos();
    }

    @And("^visualizar carrito de compras$")
    public void visualizar_carrito() throws InterruptedException {
        challengeStep.clickEnCarrito();
    }

    @And("^realizar Checkout$")
    public void realizar_chechout() throws InterruptedException {
        challengeStep.clickEnChechout();
    }

    @And("^ingresar nombres \"([^\"]*)\"$")
    public void ingresarNombres(String sNombres) throws Throwable {
        challengeStep.escribirNombres(sNombres);
    }

    @And("^ingresar apellidos \"([^\"]*)\"$")
    public void ingresarApellidos(String sApellidos) throws Throwable {
        challengeStep.escribirApellidos(sApellidos);
    }

    @And("^ingresar codigo postal \"([^\"]*)\"$")
    public void ingresarCodPostal(String sCodpostal) throws Throwable {
        challengeStep.escribirCodpostal(sCodpostal);
    }

    @And("^confirmar la informacion$")
    public void confirmar_informacion() throws InterruptedException {
        challengeStep.clickEnContinuar();
    }

    @And("^Finalizar proceso de compra$")
    public void finalizar_comprar() throws InterruptedException {
        challengeStep.clickEnFinalizar();
    }

    @Then("^Validar la generacion de la orden$")
    public void validar_orden() throws InterruptedException {
        challengeStep.validarOrden();
    }
}
