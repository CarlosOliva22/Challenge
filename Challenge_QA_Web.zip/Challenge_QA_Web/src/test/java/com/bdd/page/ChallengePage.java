package com.bdd.page;

import net.serenitybdd.core.pages.WebElementFacade;
import net.thucydides.core.annotations.DefaultUrl;
import net.thucydides.core.pages.PageObject;
import org.openqa.selenium.support.FindBy;

@DefaultUrl("https://www.saucedemo.com/ ")
public class ChallengePage extends PageObject {

    @FindBy(xpath = "//input[@id=\"user-name\"]")   //definiendo el xpath
    private WebElementFacade txtUsername;                   //asignando a la variable txtUsername el valor del xpath

    @FindBy(xpath = "//input[@id=\"password\"]")   //definiendo el xpath
    private WebElementFacade txtPassword;                   //asignando a la variable txtPassword el valor del xpath

    @FindBy(xpath = "//input[@id=\"login-button\"]")   //definiendo el xpath
    private WebElementFacade btnLogin;                            //asignando a la variable btnLogin el valor del xpath

    @FindBy(xpath = "//button[@id=\"add-to-cart-sauce-labs-bike-light\"]")   //definiendo el xpath
    private WebElementFacade btnAgregar1;                   //asignando a la variable btnAgregar1 el valor del xpath

    @FindBy(xpath = "//button[@id=\"add-to-cart-sauce-labs-bolt-t-shirt\"]")   //definiendo el xpath
    private WebElementFacade btnAgregar2;                   //asignando a la variable btnAgregar2 el valor del xpath

    @FindBy(xpath = "//div[@id=\"shopping_cart_container\"]")   //definiendo el xpath
    private WebElementFacade btnCarrito;                            //asignando a la variable btnCarrito el valor del xpath

    @FindBy(xpath = "//button[@id=\"checkout\"]")   //definiendo el xpath
    private WebElementFacade btnChechout;                            //asignando a la variable btnChechout el valor del xpath

    @FindBy(xpath = "//input[@id=\"first-name\"]")   //definiendo el xpath
    private WebElementFacade txtNmobres;                   //asignando a la variable txtNmobres el valor del xpath

    @FindBy(xpath = "//input[@id=\"last-name\"]")   //definiendo el xpath
    private WebElementFacade txtApellidos;                            //asignando a la variable txtApellidos el valor del xpath

    @FindBy(xpath = "//input[@id=\"postal-code\"]")   //definiendo el xpath
    private WebElementFacade txtCodpostal;                   //asignando a la variable txtCodpostal el valor del xpath

    @FindBy(xpath = "//input[@id=\"continue\"]")   //definiendo el xpath
    private WebElementFacade btnContinuar;                            //asignando a la variable btnContinuar el valor del xpath

    @FindBy(xpath = "//button[@id=\"finish\"]")   //definiendo el xpath
    private WebElementFacade btnFinalizar;                            //asignando a la variable btnFinalizar el valor del xpath

    //@FindBy(xpath = "//div[@id='result-stats']")
   // @FindBy(xpath = "//div[contains(text(),'Cerca de ')]")
   @FindBy(xpath = "//div[@id=\"checkout_complete_container\"]")
    private WebElementFacade msjOrden;

    public void escribirUsernameSaucedemo (String sUsername) throws InterruptedException {
        txtUsername.sendKeys(sUsername);
    }

    public void escribirPasswordSaucedemo (String sPassword) throws InterruptedException {
        txtPassword.sendKeys(sPassword);
    }
    public void clickEnLogin() throws InterruptedException {
        btnLogin.click();
    }

    public void clickEnProductos() throws InterruptedException {
        btnAgregar1.click();
        btnAgregar2.click();
    }

    public void clickEnCarrito() throws InterruptedException {
        btnCarrito.click();
    }

    public void clickEnChechout() throws InterruptedException {
        btnChechout.click();
    }

    public void escribirNombres (String sNombres) throws InterruptedException {
        txtNmobres.sendKeys(sNombres);
    }

    public void escribirApellidos (String sApellidos) throws InterruptedException {
        txtApellidos.sendKeys(sApellidos);
    }

    public void escribirCodpostal (String sCodpostal) throws InterruptedException {
        txtCodpostal.sendKeys(sCodpostal);
    }

    public void clickEnContinuar() throws InterruptedException {
        btnContinuar.click();
    }

    public void clickEnFinalizar() throws InterruptedException {
        btnFinalizar.click();
    }
    public boolean validarMsjOrden(){
        return msjOrden.getText().contains("Thank you for your order");
     }
}
