package com.bdd.step;

import com.bdd.page.ChallengePage;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;
import org.junit.Assert;

public class ChallengeStep extends ScenarioSteps {

    private ChallengePage challengePage;

    @Step
    public void cargarPaginaSaucedemo() {
        challengePage.open();
        getDriver().manage().window().maximize();
    }

    @Step
    public void escribirUsernameSaucedemo(String sUsername) throws InterruptedException {
        challengePage.escribirUsernameSaucedemo(sUsername);
    }

    @Step
    public void escribirPasswordSaucedemo(String sPassword) throws InterruptedException {
        challengePage.escribirPasswordSaucedemo(sPassword);
    }

    @Step
    public void clickEnLogin() throws InterruptedException {
        challengePage.clickEnLogin();
    }

    @Step
    public void clickEnProductos() throws InterruptedException {
        challengePage.clickEnProductos();
    }

    @Step
    public void clickEnCarrito() throws InterruptedException {
        challengePage.clickEnCarrito();
    }

    @Step
    public void clickEnChechout() throws InterruptedException {
        challengePage.clickEnChechout();
    }

    @Step
    public void escribirNombres(String sNombres) throws InterruptedException {
        challengePage.escribirNombres(sNombres);
    }

    @Step
    public void escribirApellidos(String sApellidos) throws InterruptedException {
        challengePage.escribirApellidos(sApellidos);
    }

    @Step
    public void escribirCodpostal(String sCodpostal) throws InterruptedException {
        challengePage.escribirCodpostal(sCodpostal);
    }

    @Step
    public void clickEnContinuar() throws InterruptedException {
        challengePage.clickEnContinuar();
    }

    @Step
    public void clickEnFinalizar() throws InterruptedException {
        challengePage.clickEnFinalizar();
    }
    @Step
    public void validarOrden() throws InterruptedException {
        Assert.assertTrue(challengePage.validarMsjOrden());
    }
}
